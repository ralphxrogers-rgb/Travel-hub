import { useState, useEffect } from 'react'
import { useAuth } from '../hooks/useAuth'
import { tripsApi } from '../lib/supabase'
import { format, parseISO, isFuture, isPast, differenceInDays } from 'date-fns'

const BLANK = { destination:'', country:'', start_date:'', end_date:'', status:'planning', hotel:'', booking_ref:'', points_used:'', points_program:'', notes:'' }

export default function Trips() {
  const { user } = useAuth()
  const [trips, setTrips] = useState([])
  const [loading, setLoading] = useState(true)
  const [modal, setModal] = useState(null) // null | 'add' | {trip}
  const [form, setForm] = useState(BLANK)
  const [saving, setSaving] = useState(false)

  const load = async () => {
    const { data } = await tripsApi.getAll(user.id)
    setTrips(data || [])
    setLoading(false)
  }
  useEffect(() => { if (user) load() }, [user])

  const openAdd = () => { setForm(BLANK); setModal('add') }
  const openEdit = (t) => { setForm({...BLANK,...t, points_used: t.points_used || '', start_date: t.start_date||'', end_date: t.end_date||''}); setModal(t) }
  const close = () => setModal(null)

  const save = async (e) => {
    e.preventDefault(); setSaving(true)
    const payload = { ...form, user_id: user.id, points_used: form.points_used ? parseInt(form.points_used) : 0 }
    if (modal === 'add') await tripsApi.create(payload)
    else await tripsApi.update(modal.id, payload)
    await load(); setSaving(false); close()
  }

  const del = async (id) => {
    if (!window.confirm('Delete this trip?')) return
    await tripsApi.delete(id); load()
  }

  const upcoming = trips.filter(t => t.start_date && isFuture(parseISO(t.start_date)))
  const past = trips.filter(t => !t.start_date || isPast(parseISO(t.start_date)))

  const tripCard = (trip) => (
    <div key={trip.id} className="card">
      <div className="trip-card-header">
        <div>
          <div className="trip-card-dest">{trip.destination}{trip.country ? `, ${trip.country}` : ''}</div>
          {trip.hotel && <div className="trip-card-hotel">{trip.hotel}</div>}
        </div>
        <span className={`badge ${statusBadge(trip.status)}`}>{trip.status}</span>
      </div>
      <div className="trip-card-dates">
        {trip.start_date && <span>📅 {format(parseISO(trip.start_date), 'MMM d')} – {trip.end_date ? format(parseISO(trip.end_date), 'MMM d, yyyy') : '?'}</span>}
        {trip.booking_ref && <span>Ref: {trip.booking_ref}</span>}
        {trip.points_used > 0 && <span>⭐ {trip.points_used.toLocaleString()} {trip.points_program || 'pts'}</span>}
      </div>
      {trip.notes && <div style={{fontSize:13,color:'var(--text-2)',marginTop:8,fontStyle:'italic'}}>{trip.notes}</div>}
      <div className="trip-card-actions">
        <button className="btn btn-sm" onClick={() => openEdit(trip)}>Edit</button>
        <button className="btn btn-sm btn-danger" onClick={() => del(trip.id)}>Delete</button>
      </div>
    </div>
  )

  if (loading) return <div className="spinner" />

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Trips</h1>
          <p className="page-subtitle">{trips.length} trip{trips.length !== 1 ? 's' : ''} tracked</p>
        </div>
        <button className="btn btn-primary" onClick={openAdd}>+ Add trip</button>
      </div>

      {upcoming.length > 0 && <>
        <div className="section-label">Upcoming</div>
        <div className="card-grid">{upcoming.map(tripCard)}</div>
      </>}
      {past.length > 0 && <>
        <div className="section-label">Past trips</div>
        <div className="card-grid">{past.map(tripCard)}</div>
      </>}
      {trips.length === 0 && (
        <div className="empty-state">
          <div className="empty-state-icon">✈️</div>
          <div className="empty-state-title">No trips yet</div>
          <div className="empty-state-text">Add your first trip to start organizing your travel.</div>
        </div>
      )}

      {modal && (
        <div className="modal-backdrop" onClick={close}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <div className="modal-title">{modal === 'add' ? 'New trip' : 'Edit trip'}</div>
              <button className="modal-close" onClick={close}>×</button>
            </div>
            <form onSubmit={save}>
              <div className="form-grid">
                <div className="form-group" style={{gridColumn:'1/-1'}}>
                  <label className="form-label">Destination *</label>
                  <input className="form-input" required value={form.destination} onChange={e => setForm(f=>({...f, destination:e.target.value}))} placeholder="e.g. Maui, Hawaii" />
                </div>
                <div className="form-group">
                  <label className="form-label">Country</label>
                  <input className="form-input" value={form.country} onChange={e => setForm(f=>({...f, country:e.target.value}))} placeholder="USA" />
                </div>
                <div className="form-group">
                  <label className="form-label">Status</label>
                  <select className="form-select" value={form.status} onChange={e => setForm(f=>({...f, status:e.target.value}))}>
                    <option value="planning">Planning</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Start date</label>
                  <input className="form-input" type="date" value={form.start_date} onChange={e => setForm(f=>({...f, start_date:e.target.value}))} />
                </div>
                <div className="form-group">
                  <label className="form-label">End date</label>
                  <input className="form-input" type="date" value={form.end_date} onChange={e => setForm(f=>({...f, end_date:e.target.value}))} />
                </div>
                <div className="form-group" style={{gridColumn:'1/-1'}}>
                  <label className="form-label">Hotel / Property</label>
                  <input className="form-input" value={form.hotel} onChange={e => setForm(f=>({...f, hotel:e.target.value}))} placeholder="e.g. Hilton Grand Wailea" />
                </div>
                <div className="form-group">
                  <label className="form-label">Booking reference</label>
                  <input className="form-input" value={form.booking_ref} onChange={e => setForm(f=>({...f, booking_ref:e.target.value}))} placeholder="HGV-4821" />
                </div>
                <div className="form-group">
                  <label className="form-label">Points used</label>
                  <input className="form-input" type="number" value={form.points_used} onChange={e => setForm(f=>({...f, points_used:e.target.value}))} placeholder="0" min="0" />
                </div>
                <div className="form-group">
                  <label className="form-label">Points program</label>
                  <input className="form-input" value={form.points_program} onChange={e => setForm(f=>({...f, points_program:e.target.value}))} placeholder="Hilton Honors" />
                </div>
                <div className="form-group" style={{gridColumn:'1/-1'}}>
                  <label className="form-label">Notes</label>
                  <textarea className="form-textarea" value={form.notes} onChange={e => setForm(f=>({...f, notes:e.target.value}))} placeholder="Any details, reminders…" />
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn" onClick={close}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save trip'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

function statusBadge(s) {
  return { planning:'badge-amber', confirmed:'badge-green', completed:'badge-gray', cancelled:'badge-red' }[s] || 'badge-gray'
}
